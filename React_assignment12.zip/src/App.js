import './App.css';
import Postview from './Postview';

function App() {
  return (
    <div className="App">
       < Postview/>
    </div>
  );
}

export default App;
